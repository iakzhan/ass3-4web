const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const appRoutes = require('./routes/appRoutes');

const app = express();

mongoose.connect('mongodb+srv://<username>:qwerty@cluster0.x574gz2.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  // Remove the deprecated options
  // useNewUrlParser: true,
  // useUnifiedTopology: true,
  // Instead, specify the new options directly in the URI
  // For example, to ensure compatibility with future MongoDB driver versions:
  // mongodb://localhost:27017/cinemaDB?retryWrites=true&w=majority
  // You can adjust these options as per your requirements
})
.then(() => {
  console.log('MongoDB connected');
})
.catch((err) => {
  console.error('Error connecting to MongoDB:', err);
});

const userRoutes = require('./routes/userRoutes');
const { decode } = require("jsonwebtoken");

app.use(bodyParser.json());

app.use('/user', userRoutes);
app.use('/', appRoutes);
app.use('/api', userRoutes);

const port = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'styles')));
app.use(express.static(path.join(__dirname, 'scripts')));
app.use(express.static(path.join(__dirname, 'pages')));
app.use(express.static(path.join(__dirname, 'routes')));
app.use(express.static(path.join(__dirname, 'controllers')));

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
